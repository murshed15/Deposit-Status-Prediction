<?php session_start() ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Deposit Status Prediction</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        .age{
            font-size: 20px;
            font-weight: 500;
        }
        body {
            background-image: url("14.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            margin: 0;
            font-family: var(--bs-body-font-family);
            font-size: var(--bs-body-font-size);
            font-weight: var(--bs-body-font-weight);
            line-height: var(--bs-body-line-height);
            color: var(--bs-body-color);
            text-align: var(--bs-body-text-align);
            background-color: #acdfb3 !important;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
            margin-top: 30px;
        }
        .bank{
            text-align: center;
        }
        .container{
            margin-left: 35%;
        }
        .hgfd::before {
            position: fixed; /* Sit on top of the page content */
            display: none; /* Hidden by default */
            width: 100%; /* Full width (cover the whole page) */
            height: 100%; /* Full height (cover the whole page) */
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.5); /* Black background with opacity */
            z-index: 2; /* Specify a stack order in case you're using a different order for other elements */
            cursor: pointer; /* Add a pointer on hover */
        }
    </style>
</head>
  <body class="hgfd">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
            <h2 class="bank">Bank Deposit Status</h2>
    <form method="post" action="bank_post.php" class="jon">
        <label for="">
            <p class="age">Job:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Marital:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Education:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Loan:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Contact:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Day:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Month:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Duration:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Campaign:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="">
            <p class="age">Pdays:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br><label for="">
            <p class="age">Previous:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br><label for="">
            <p class="age">Poutcome:</p>
        </label>
        <input class="form-control" type="text" name="" required>
        <br>
        <label for="balance">
            <p class="age">Deposit Balance:</p>
        </label>
        <input class="form-control" type="text" name="balance" required>
        <?php if(isset($_SESSION['balance'])){ ?>
                <div class="alert alert-danger">
                    <?php echo $_SESSION['balance']; ?>
                </div>
        <?php } ?>
        <?php if(isset($_SESSION['balance_error'])){ ?>
                <div class="alert alert-danger">
                    <?php echo $_SESSION['balance_error']; ?>
                </div>
        <?php } ?>
        <br>
        <button class="btn btn-info" type="submit">Submit</button>
    </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php session_unset(); ?>

