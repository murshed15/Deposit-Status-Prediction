<?php 

session_start();
// print_r($_POST['balance']);
$balance = $_POST['balance'];


$db_connect = mysqli_connect('localhost', 'root', '', 'anik');


$select_query = "SELECT COUNT(*) FROM `bank` WHERE `COL 6`='$balance'";
$query_implement = mysqli_query($db_connect,$select_query);
$after_assoc = mysqli_fetch_assoc($query_implement);

// print_r($after_assoc['COUNT(*)']);

if ($after_assoc['COUNT(*)']==1) {
    $_SESSION['balance'] = "Congratulations you have a Deposit...";
    header('location: index.php');
}
else{
    $_SESSION['balance_error'] = "Sorry, You don't have any Deposit...";
    header('location: index.php');
}

?>